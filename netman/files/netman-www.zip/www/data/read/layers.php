{
    "success": true,
    "data": [
	{"Name":"-","id":"0","leaf":false,"loaded":true},
	{"Name":"Access","id":"1","leaf":false,"loaded":true},
	{"Name":"Distribution","id":"2","leaf":false,"loaded":true},
	{"Name":"Core","id":"3","leaf":false,"loaded":true},
	{"Name":"Edge","id":"4","leaf":false,"loaded":true},
    ]    
}
