{
    "success": true,
    "data": [
	{"Name":"-","id":"0","leaf":false,"loaded":true},
	{"Name":"Critical","id":"1","leaf":false,"loaded":true},
	{"Name":"Error","id":"2","leaf":false,"loaded":true},
	{"Name":"Warning","id":"3","leaf":false,"loaded":true},
	{"Name":"Info","id":"4","leaf":false,"loaded":true},
	{"Name":"Debug","id":"5","leaf":false,"loaded":true},
    ]    
}
