<?php
require("../session.php");
echo "{ 'success': 'OK'}";
?>
