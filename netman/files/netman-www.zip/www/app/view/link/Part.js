Ext.define('netman.view.link.Part', {
	extend: 'netman.view.link.Portlet',
});
