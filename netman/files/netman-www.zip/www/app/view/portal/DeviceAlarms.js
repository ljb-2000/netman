Ext.define('netman.view.portal.DeviceAlarms', {
	extend: 'netman.view.portal.Portlet',
	alias: "widget.devicealarms",
	title: 'Active Alarms per Device',
	items:[{
		xtype: 'container',
		html: 'Device alarms here'
	}]
});
