Ext.define('netman.view.portal.Graph', {
	extend: 'netman.view.portal.Portlet',
	requires: ['Ext.chart.*'],
	alias: "widget.graph",
	title: 'Graph Example',
	items:[{
		
	}]
});
