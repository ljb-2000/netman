Ext.define('netman.view.portal.Intro', {
	extend: 'netman.view.portal.Portlet',
	alias: "widget.intro",
	title: 'Dashboard Introduction',
	items:[{
		xtype: 'container',
		html: 'Introduction for the dashboard'
		
	}]
});
