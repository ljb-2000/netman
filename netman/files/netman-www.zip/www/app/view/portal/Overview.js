Ext.define('netman.view.portal.Overview', {
	extend: 'netman.view.portal.Portlet',
	alias: "widget.overview",
	title: 'System Overview',
	items:[{
		xtype: 'container',
		html: 'System Overview goes here'
	}]
});
