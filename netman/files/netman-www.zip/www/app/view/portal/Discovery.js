Ext.define('netman.view.portal.OfflineDevices', {
	extend: 'netman.view.portal.Portlet',
	alias: "widget.offlinedevices",
	title: 'Offline Devices',
	items:[{
		xtype: 'container',
		html:'Offline Devices list will go here'
	}]
});
