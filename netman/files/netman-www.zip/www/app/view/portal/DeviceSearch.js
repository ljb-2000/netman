Ext.define('netman.view.portal.DeviceSearch', {
	extend: 'netman.view.portal.Portlet',
	alias: "widget.devicesearch",
	title: 'Offline Devices',
	items:[{
		xtype: 'container',
		html: ' Device Search form with auto jump'
	}]
});
