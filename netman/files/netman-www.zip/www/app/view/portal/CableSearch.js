Ext.define('netman.view.portal.CableSearch', {
	extend: 'netman.view.portal.Portlet',
	alias: "widget.cablesearch",
	title: 'Cable Search',
	items:[{
		xtype: 'container',
		html: 'Cable search goes here'
	}]
});
