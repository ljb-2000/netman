Ext.define('netman.view.device.Vlans', {
        extend: 'Ext.panel.Panel',
	title: 'Device Vlans',
	alias: 'widget.devicevlans',
});
