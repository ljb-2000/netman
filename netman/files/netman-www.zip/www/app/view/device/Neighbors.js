Ext.define('netman.view.device.Neighbors', {
        extend: 'Ext.panel.Panel',
	title: ' Device Neighbors',
	alias: 'widget.deviceneighbors',
});
