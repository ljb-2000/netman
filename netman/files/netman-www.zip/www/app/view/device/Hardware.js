Ext.define('netman.view.device.Hardware', {
        extend: 'Ext.panel.Panel',
	title: 'Device Hardware',
	alias: 'widget.devicehardware',
});
