Ext.define('netman.model.Domain', {
	extend: 'Ext.data.Model',
	fields:[
		{name:'id',type:'int'},
		{name:'Name',type:'string'},
	]
	
});

