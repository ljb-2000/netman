Ext.define('netman.model.Durations', {
	extend: 'Ext.data.Model',
	fields:[
		{name:'Name',type:'string'},
		{name:'Seconds',type:'int'},
	]
	
});
