Ext.define('netman.model.Components',{
	extend: 'Ext.data.Model',
	fields: [
		{name:'id',type:'number'},
		{name:'Name',type:'string'},
	]
});
