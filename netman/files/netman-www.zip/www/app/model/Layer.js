Ext.define('netman.model.Layer', {
	extend: 'Ext.data.Model',
	fields:[
		{name:'id',type:'string'},
		{name:'Name',type:'string'},
	]
	
});
