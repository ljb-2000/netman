Define('netman.model.Bookmark', {
	extend: 'Ext.data.Model',
	fields:[
		{name:'id',type:'int'},
		{name:'Uri',type:'string'},
		{name:'User',type:'int'}
	]
	
});
