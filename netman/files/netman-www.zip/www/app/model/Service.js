Ext.define('netman.model.Service', {
	extend: 'Ext.data.Model',
	fields:[
		{name:'Name',type:'string'},
		{name:'Status',type:'string'},
	]
	
});
