Ext.define('netman.model.State', {
	extend: 'Ext.data.Model',
	fields:[
		{name:'Name',type:'string'},
	]
	
});
