Ext.define('netman.model.Severity', {
	extend: 'Ext.data.Model',
	fields:[
		{name:'id',type:'string'},
		{name:'Name',type:'string'},
	]
	
});
